/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import implementation.PayrollImplementation;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author nerimae
 */
public class Server {
    private static Connection con; 
    public static void main(String[] args){
        try {
            Registry reg = LocateRegistry.createRegistry(1099);
            PayrollImplementation impl = new PayrollImplementation();
            reg.rebind("login", (Remote)impl);
            reg.rebind("timein", (Remote)impl);
            reg.rebind("register", (Remote)impl);
            System.out.println("Server ready");
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            String conStr = "jdbc:mysql://localhost:3306/payroll?user=root&password=1234";
            con = DriverManager.getConnection(conStr);            
            System.out.println("connected");
            
            Statement st = con.createStatement();
            st.executeUpdate("INSERT INTO employee " +
                "VALUES ('', 'Simpson', 'jgei', 'Springfield', 'qefef','qqwgf','ehfiqefh','jhf','erhewr','erherh','erhewrh','wh89we','wgw9890','')");
          

        } catch (Exception e) {
            e.printStackTrace();
        }
        
       
           
    }
    
  
}