/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation;

import interfaces.PayrollInterface;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import static javax.management.remote.JMXConnectorFactory.connect;
import static javax.rmi.PortableRemoteObject.connect;

/**
 *
 * @author nerimae
 */
public class PayrollImplementation extends UnicastRemoteObject implements PayrollInterface{

    String conStr = "jdbc:mysql://localhost:3306/payroll?user=root&password=1234";
    Connection connect;
    public PayrollImplementation() throws RemoteException, SQLException{
        
    }

    @Override
    public void register() throws RemoteException {
        
    }

    /**
     *
     * @param username
     * @param password
     * @return
     * @throws RemoteException
     * @throws SQLException
     */
    @Override
    public boolean login(String username, String password) throws RemoteException, SQLException {
        Statement st = connect.createStatement();
        String query = "SELECT empID, password from employee";
        ResultSet rs = st.executeQuery(query);
        while(rs.next()){
            String uname = rs.getString("empID");
        }
      return false; 
    } 

    @Override
    public boolean timeIn(Calendar time, Calendar date) throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean timeOut(Calendar time, Calendar date) throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean logout(String username, String password) throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   
}
