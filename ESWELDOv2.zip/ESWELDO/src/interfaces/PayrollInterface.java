/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import java.rmi.Remote;
import java.rmi.*;
import java.util.Calendar;
import java.sql.*;

/**
 *
 * @author nerimae
 */
public interface PayrollInterface extends Remote{

    public void register(String fname, String mname, String lname, String add, String mobile, Calendar date, String email) throws RemoteException;
    
    public boolean login(String username, String password) throws RemoteException, SQLException;
    
    public boolean timeIn(Calendar time, Calendar date) throws RemoteException;
    
    public boolean timeOut(Calendar time, Calendar date) throws RemoteException;
    
    public boolean logout(String username, String password) throws RemoteException;
    
}
